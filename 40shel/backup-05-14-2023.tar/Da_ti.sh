#!/bin/bash
year=`date +%Y`
month=`date +%m`
day=`date +%d`
hour=`date +%H`
minute=`date +%M`
second=`date +%S`
echo `date`

echo "Current Date is: $day-$month-$year"
echo "Current Time is: $hour:$minute:$second"
