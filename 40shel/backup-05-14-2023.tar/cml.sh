#!/bin/bash 

echo "Total no. of argument : $#"

echo "program name : $0"
echo "1st program ardument : $0"
echo "2nd program argument : $1"
echo "3rd program arguments ; $2"
echo "3rd argument: $3"
