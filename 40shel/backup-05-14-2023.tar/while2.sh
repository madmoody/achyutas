#!/bin/bash

i=0

while [ $i -le 3 ]
do 
echo number : $i
((i++))
done

