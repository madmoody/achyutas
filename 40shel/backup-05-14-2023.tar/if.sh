#!/bin/bash
num1=5
num2=2

if [ $num1 == $num2 ]
then
	echo "a is equal to b"

else

	echo "a is not equal"
fi

if [ $num1 == 0 ]
then
	echo "this is Zero"
fi	
