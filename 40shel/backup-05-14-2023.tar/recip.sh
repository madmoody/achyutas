#!/bin/bash

echo -n "enter the value"
read name

echo "i entered $name"

