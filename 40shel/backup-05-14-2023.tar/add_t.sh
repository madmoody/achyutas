#!/bin/bash

echo -n "enter the first number"
read X
echo -n "enter the second number"
read y
(( sum=X+y ))
echo "The Result of addition=$sum"

