#!/bin/bash

string1="PAVAN"
string2=" MOODY"

string=$string1$string2

echo "$string this is my full name"

