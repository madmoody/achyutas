#! /bin/bash 
echo "HELLO WORLD"
echo "iam pavan"  #this is comment
echo our shell name is  $BASH #it will show the bash
echo $BASH_VERSION   version of bash
echo $BASH_VERSION
echo our home directory $HOME	     #root directory
echo current working directory  $PWD	     #home directory

name=pavan
echo $name    #$ act as printing command for variable
echo The name is $name
val=10
echo value $val
