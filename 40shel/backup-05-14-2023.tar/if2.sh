#!/bin/bash
echo -n "enter ther number"
read num

if [ $num -gt 10 ]
then
echo "number is greater then 10"

fi
