#!/bin/bash

echo "Printing text"
echo -n "printing text without new line"
echo -e "\nRemoving \t special \t characters \n"

