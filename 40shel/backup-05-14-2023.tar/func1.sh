#!/bin/bash

function print_hello()
{
echo "==="
echo "hell"
echo "==="

}
print_hello
