#!/bin/bash
 count=0

 for i  in 0 1 2 3 4

do 
  echo "Loop value is :  $count"
  count=$((count + 1))

done

