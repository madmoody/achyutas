#!/bin/bash

: '
This scripts calculate the square of 5.
'

((area=5*5))

echo $area

