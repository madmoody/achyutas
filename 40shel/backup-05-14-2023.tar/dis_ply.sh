#!/bin/bash

ls -lrt | grep ^- | awk 'END{print $NF}'
