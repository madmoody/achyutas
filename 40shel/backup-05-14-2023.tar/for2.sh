#!/bin/bash

for (( count=0; count<=10; count++ ))
do 
echo -n " $count"
done
printf "\n"

