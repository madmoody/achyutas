#!/bin/bash
echo -n "Enter filename ->"
read name
rm -i $name
