#!/bin/bash

((SUM=25+32))

echo $SUM
