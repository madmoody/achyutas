#!/bin/bash

echo "Total arguments : $#"
echo "First arguments : $1"
echo "Second arguments : $2"

