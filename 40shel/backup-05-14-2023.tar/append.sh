#!/bin/bash
echo "Before appending the file"
cat editors.txt

echo "6.NotePad++" >> editors.txt
echo "After appending the file"
cat editors.txt

