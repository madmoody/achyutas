#!/bin/bash

str1="HELLO"
str2="HELLO"

if [ $str1 = $str2 ]
then 
    echo "match"
else
    echo "No match"
 fi
