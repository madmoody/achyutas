#!/bin/bash
str1="HELLO"

if [ -z "${str1}" ]
then 
 echo "string is empty"
else
 echo "string is not empty"
fi

