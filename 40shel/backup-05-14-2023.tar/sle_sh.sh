#!/bin/bash
echo "How long to wait?"
read time
sleep $time
echo "Waited for $time seconds!"
