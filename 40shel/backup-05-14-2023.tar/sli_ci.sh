#!/bin/bash
str="I Love Bengalore"

subStr=${Str:0:10}
echo $subStr

